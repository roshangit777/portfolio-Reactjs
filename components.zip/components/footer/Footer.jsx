import React from 'react'
import './footer.css'

const Footer = () => {
  return (
    <section id="footer">Footer</section>
  )
}

export default Footer