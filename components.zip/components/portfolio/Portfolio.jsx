import React from 'react'
import './portfolio.css'
import IMG1 from '../../Assets/p1.webp'
import IMG2 from '../../Assets/p2.webp'
import IMG3 from '../../Assets/p3.webp'
import IMG4 from '../../Assets/p4.webp'
import IMG5 from '../../Assets/p5.webp'
import IMG6 from '../../Assets/p6.webp'

const Portfolio = () => {
  return (
    <section id="portfolio">
    <h5>My React Work</h5>
    <h2>Portfolio</h2>
  

    <div className='container portfolio_container'>
      <article className='portfolio_item'>
        <div className='portfolio_item-image'>
          <img src={IMG1} alt=""/>
        </div>
        <h3>Finance Landing Page</h3>
        <div className='portfolio_item-cta'>
        <a href='https://github.com' className='btn' target='_blank'>Github</a>
        <a href='https://dribbble.com/shots/popular/web-design.com' className='btn btn-primary' target='_blank'>Live Demo</a>
        </div>
      </article>
      <article className='portfolio_item'>
        <div className='portfolio_item-image'>
          <img src={IMG2} alt=""/>
        </div>
        <h3> Creative Digital Agency Landing Page</h3>
        <div className='portfolio_item-cta'>
        <a href='https://github.com' className='btn' target='_blank'>Github</a>
        <a href='https://dribbble.com/shots/popular/web-design.com' className='btn btn-primary' target='_blank'>Live Demo</a>
        </div>
      </article>
      <article className='portfolio_item'>
        <div className='portfolio_item-image'>
          <img src={IMG3} alt=""/>
        </div>
        <h3>Credit Card Landing Page</h3>
        <div className='portfolio_item-cta'>
        <a href='https://github.com' className='btn' target='_blank'>Github</a>
        <a href='https://dribbble.com/shots/popular/web-design.com' className='btn btn-primary' target='_blank'>Live Demo</a>
        </div>
      </article>
      <article className='portfolio_item'>
        <div className='portfolio_item-image'>
          <img src={IMG4} alt=""/>
        </div>
        <h3>Untitled UI</h3>
        <div className='portfolio_item-cta'>
        <a href='https://github.com' className='btn' target='_blank'>Github</a>
        <a href='https://dribbble.com/shots/popular/web-design.com' className='btn btn-primary' target='_blank'>Live Demo</a>
        </div>
      </article>
      <article className='portfolio_item'>
        <div className='portfolio_item-image'>
          <img src={IMG5} alt=""/>
        </div>
        <h3>Onplay UI-UX</h3>
        <div className='portfolio_item-cta'>
        <a href='https://github.com' className='btn' target='_blank'>Github</a>
        <a href='https://dribbble.com/shots/popular/web-design.com' className='btn btn-primary' target='_blank'>Live Demo</a>
        </div>
      </article>
      <article className='portfolio_item'>
        <div className='portfolio_item-image'>
          <img src={IMG6} alt=""/>
        </div>
        <h3>Academy landing page</h3>
        <div className='portfolio_item-cta'>
        <a href='https://github.com' className='btn' target='_blank'>Github</a>
        <a href='https://dribbble.com/shots/popular/web-design.com' className='btn btn-primary' target='_blank'>Live Demo</a>
        </div>
      </article>
    
    </div>
    </section>
  )
}

export default Portfolio