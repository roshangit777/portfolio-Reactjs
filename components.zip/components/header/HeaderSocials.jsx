import React from 'react'
import {BsLinkedin} from 'react-icons/bs'
import {AiFillGithub} from 'react-icons/ai'
import {AiFillFacebook} from 'react-icons/ai'

const HeaderSocials = () => {
    return (
        <div className='header__socials'>
            <a href="https://linkedin.com" targer="_blank"><BsLinkedin/></a>
            <a href="https://github.com" targer="_blank"><AiFillGithub/></a>
            <a href="https://facebook.com" targer="_blank"><AiFillFacebook/></a>
            
        </div>
    )
}

export default HeaderSocials
