import React from 'react'
import './contact.css'

const contacts = () => {
  return (
    <section id="contact">contacts</section>
  )
}

export default contacts